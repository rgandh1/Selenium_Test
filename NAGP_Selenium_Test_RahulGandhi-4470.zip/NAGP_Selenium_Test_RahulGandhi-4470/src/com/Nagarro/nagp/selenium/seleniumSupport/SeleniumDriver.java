package com.Nagarro.nagp.selenium.seleniumSupport;

import org.openqa.selenium.WebDriver;

public class SeleniumDriver 
{

	public static WebDriver driver;
	public static String pathOfDrivers;	
}// end of Class
